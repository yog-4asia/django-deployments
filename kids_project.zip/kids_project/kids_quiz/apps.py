from django.apps import AppConfig


class KidsQuizConfig(AppConfig):
    name = 'kids_quiz'
