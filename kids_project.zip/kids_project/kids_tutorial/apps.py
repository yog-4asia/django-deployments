from django.apps import AppConfig


class KidsTutorialConfig(AppConfig):
    name = 'kids_tutorial'
