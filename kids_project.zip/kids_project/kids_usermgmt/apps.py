from django.apps import AppConfig


class KidsUsermgmtConfig(AppConfig):
    name = 'kids_usermgmt'
